export const REQUEST_TOKEN = 'Bearer 580792';
export const CURRENT_VERSION = chrome.runtime.getManifest().version
export const MEET_CODE = window.location.href.split('/').slice(-1).toString().slice(0, 12);
export const CHAT_LINK = 'https://adventurous-glorious-actor.glitch.me/stream-messages'
export const DASHBOARD_LINK = 'https://nobeltt.com'
export const DATE = new Date().toISOString().split('T')[0]